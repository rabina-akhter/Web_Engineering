<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventName = trim($_POST['eventName']);
    $eventDate = $_POST['eventDate'];
    $tickets = intval($_POST['tickets']);
    $category = $_POST['category'];
    if (empty($eventName) || empty($eventDate) || $tickets <= 0 || empty($category)) {
        die("⚠ Invalid input. Please check your form.");
    }
    $stmt = $conn->prepare("INSERT INTO events (eventName, eventDate, tickets, category) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $eventName, $eventDate, $tickets, $category);

    if ($stmt->execute()) {
        echo "<script>
                alert('✅ Event added successfully!');
                window.location.href='admin.html';
              </script>";
    } else {
        echo "❌ Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    die("⚠ Invalid request method.");
}
?>