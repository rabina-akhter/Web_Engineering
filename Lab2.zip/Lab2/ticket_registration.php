<?php
session_start();
include 'db.php';
$userEmail = $_SESSION['email'] ?? null;
if (!$userEmail) {
    header("Location: login.html");
    exit;
}

$events = $conn->query("SELECT * FROM events ORDER BY eventDate ASC");
$stmt = $conn->prepare("SELECT eventName, eventDate, status FROM bookings WHERE userEmail = ?");
$stmt->bind_param("s", $userEmail);
$stmt->execute();
$userBookings = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Portal - Campus Fest 2025</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Campus Fest 2025 - Student Portal</h1>
        <nav>
            <a href="student.php">Home</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <section class="intro">
            <h2>Welcome, Student!</h2>
            <p>Browse upcoming events and book your tickets.</p>
        </section>

        <section class="events">
            <h2>Available Events</h2>
            <table id="eventsTable">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Tickets Available</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $events->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['eventName']) ?></td>
                            <td><?= htmlspecialchars($row['category']) ?></td>
                            <td><?= htmlspecialchars($row['eventDate']) ?></td>
                            <td><?= $row['tickets'] ?></td>
                            <td>
                                <?php if ($row['tickets'] > 0): ?>
                                    <form method="POST" action="book_event.php">
                                        <input type="hidden" name="eventName" value="<?= $row['eventName'] ?>">
                                        <input type="hidden" name="eventDate" value="<?= $row['eventDate'] ?>">
                                        <button type="submit">Book</button>
                                    </form>
                                <?php else: ?>
                                    <button disabled>Not Available</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <h3>Your Active Bookings</h3>
            <table id="myBookings">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($b = $userBookings->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($b['eventName']) ?></td>
                            <td><?= htmlspecialchars($b['eventDate']) ?></td>
                            <td><?= $b['status'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Greenfield University</p>
    </footer>
</body>
</html>
