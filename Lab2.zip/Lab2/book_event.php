<?php
session_start();
include 'db.php';

$userEmail = $_SESSION['email'] ?? null;
if (!$userEmail) {
    header("Location: login.html");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventName = $_POST['eventName'];
    $eventDate = $_POST['eventDate'];

    $stmt = $conn->prepare("SELECT tickets FROM events WHERE eventName=? AND eventDate=? LIMIT 1");
    $stmt->bind_param("ss", $eventName, $eventDate);
    $stmt->execute();
    $result = $stmt->get_result();
    $event = $result->fetch_assoc();

    if ($event) {
        if ($event['tickets'] > 0) {
            $conn->query("UPDATE events SET tickets = tickets - 1 WHERE eventName='$eventName' AND eventDate='$eventDate'");
            $stmt = $conn->prepare("INSERT INTO bookings (userEmail, eventName, eventDate, status) VALUES (?, ?, ?, 'booked')");
            $stmt->bind_param("sss", $userEmail, $eventName, $eventDate);
            $stmt->execute();
            echo "<script>alert('✅ Ticket booked successfully!'); window.location.href='student.php';</script>";
        } else {
            $stmt = $conn->prepare("INSERT INTO bookings (userEmail, eventName, eventDate, status) VALUES (?, ?, ?, 'waiting')");
            $stmt->bind_param("sss", $userEmail, $eventName, $eventDate);
            $stmt->execute();
            echo "<script>alert('⚠ Event full. You are added to the waiting list.'); window.location.href='student.php';</script>";
        }
    }
}
?>
