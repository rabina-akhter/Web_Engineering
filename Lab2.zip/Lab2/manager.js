document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");

    form.addEventListener("submit", (event) => {
        let isValid = true;
        let messages = [];

        const eventName = form.eventName.value.trim();
        const eventDate = form.eventDate.value;
        const tickets   = form.tickets.value;
        const category  = form.category.value;
        if (eventName.length < 3) {
            isValid = false;
            messages.push("Event name must be at least 3 characters long.");
        }
        if (!eventDate) {
            isValid = false;
            messages.push("Please select an event date.");
        } else {
            const today = new Date();
            const selectedDate = new Date(eventDate);
            if (selectedDate < today.setHours(0, 0, 0, 0)) {
                isValid = false;
                messages.push("Event date cannot be in the past.");
            }
        }

        if (!tickets || tickets <= -0) {
            isValid = false;
            messages.push("Tickets must be greater than 0.");
        }
        if (!category) {
            isValid = false;
            messages.push("Please select a category.");
        }

        if (!isValid) {
            event.preventDefault();
            alert(messages.join("\n"));
        }
    });
});
