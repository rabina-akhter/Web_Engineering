<?php
include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($password === "12345admin") {
        $_SESSION['role'] = "admin";
        $_SESSION['email'] = $email;
        header("Location: admin.html");
        exit;
    }

    elseif ($password === "12345user") {
        $_SESSION['role'] = "user";
        $_SESSION['email'] = $email;
        $stmt = $conn->prepare("INSERT IGNORE INTO users (email) VALUES (?)");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->close();

        header("Location: ticket_registration.php");
        exit;
    }

    else {
        echo "<script>
                alert('❌ Invalid email or password.');
                window.location.href='login.html';
              </script>";
    }
}
?>
