<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop With Me</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header>
        <div class="left">Shop With Me</div>
        <nav class="center">
            <a href="#" onclick="location.reload()">Home</a>
            <div class="dropdown">
                <a href="#">Items ▼</a>
                <div class="dropdown-content">
                    <a href="#">Fruits</a>
                    <a href="#">Meats</a>
                    <a href="#">Groceries</a>
                </div>
            </div>
            <div class="dropdown">
                <a href="#">Offers ▼</a>
                <div class="dropdown-content">
                    <a href="#">Meal For Two</a>
                    <a href="#">Family Pack</a>
                    <a href="#">Iftar Offer</a>
                </div>
            </div>
            <input type="text" placeholder="Type your item" />
            <button id="search-btn">Search</button>
        </nav>
        <div class="right">
            <a href="orders.php" class="cart-icon">🛒 <span class="cart-number">0</span></a>
        </div>
    </header>

    <main>
        <div class="slider">
            <div class="slider-overlay-text">Discounted Offer</div>
            <div class="slides">
                <img src="https://img.lovepik.com/photo/45009/3194.jpg_wh860.jpg" />
                <img src="https://cdn.create.vista.com/downloads/f5dc318e-899e-43d8-b7fc-0bd42c48e82f_360.jpeg" />
                <img src="https://i.pinimg.com/736x/a6/88/e5/a688e56298c7cc59b7e571ea7d3801ff.jpg" />
            </div>
        </div>

        <div class="products"></div>

        <div class="order-now-container">
            <button class="order-now-btn" onclick="alert('Order placed!')">Order Now</button>
        </div>
    </main>

    <footer>Thank you for watching</footer>

    <script src="script.js"></script>
</body>
</html>
