<?php
include('db_connect.php');

if (isset($_POST['register'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $birthdate = $_POST['birth_date'];
    $password = $_POST['password'];
    $reg_date = date("Y-m-d H:i:s");

    // Validate email
    if (!preg_match("/^[a-zA-Z0-9._%+-]+@diu\.edu\.bd$/", $email)) {
        echo "<script>alert('Only DIU emails allowed!');</script>";
    } elseif (!preg_match("/^[A-Za-z0-9@]+$/", $password)) {
        echo "<script>alert('Password must contain only A-Z, a-z, 0-9, @');</script>";
    } else {
        $hashed = password_hash($password, PASSWORD_BCRYPT);

        // Insert new user
        $stmt = $conn->prepare("INSERT INTO users (email, name, birth_date, password, registration_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $email, $name, $birthdate, $hashed, $reg_date);

        if ($stmt->execute()) {
            $user_id = $stmt->insert_id;
            $serial_id = date('Ymd', strtotime($birthdate)) . '-' . $user_id;

            // Update with serial_id
            $update_stmt = $conn->prepare("UPDATE users SET serial_id = ? WHERE id = ?");
            $update_stmt->bind_param("si", $serial_id, $user_id);

            if ($update_stmt->execute()) {
                header("Location: login.php");
                exit();
            } else {
                echo "Error updating serial_id: " . $update_stmt->error;
            }
        } else {
            echo "Error inserting user: " . $stmt->error;
        }
    }
}
?>
