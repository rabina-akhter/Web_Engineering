<?php

include('db_connection.php'); 


$year = $_GET['year'];


$result = $conn->query("SELECT COUNT(*) AS count FROM users WHERE serial LIKE '$year-%'");

if ($result) {
    $row = $result->fetch_assoc();
    $count = str_pad($row['count'] + 1, 3, '0', STR_PAD_LEFT); 
    echo "$year-$count"; 
} else {
    echo "Error: " . $conn->error; 
}
?>
