<?php include('db_connect.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="form-box">
        <h2>Login</h2>
        <form action="" method="POST">
            <input type="text" name="identifier" placeholder="Email or Serial" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Enter</button>
        </form>
    </div>
</body>
</html>

<?php
session_start();
if (isset($_POST['login'])) {
    $id = $_POST['identifier'];
    $pass = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR serial = ?");
    $stmt->bind_param("ss", $id, $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $user = $res->fetch_assoc();
        if (password_verify($pass, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            header("Location: home.php");
        } else {
            echo "<script>alert('Incorrect password');</script>";
        }
    } else {
        echo "<script>alert('User not found');</script>";
    }
}
?>
