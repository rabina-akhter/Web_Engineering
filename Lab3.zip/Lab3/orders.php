<?php
session_start();
include("db_connect.php");

$user_id = $_SESSION['user_id']; 


if (isset($_POST['add'])) {
    $pname = $_POST['product_name'];
    $qty = $_POST['quantity'];
    $price = $_POST['price']; 
    $serial_id = $_SESSION['user_id']; 
    $amount = $qty * $price;

    $stmt = $conn->prepare("INSERT INTO orders (user_id, serial_id, order_name, quantity, amount) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issdi", $_SESSION['user_id'], $serial_id, $pname, $qty, $amount);

    if ($stmt->execute()) {
        echo "Order added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}


$query = "SELECT * FROM orders WHERE user_id = $user_id";
$result = $conn->query($query);


echo "<table border='1'>";
echo "<tr><th>Order ID</th><th>Order Date</th><th>Serial ID</th><th>Product Name</th><th>Quantity</th><th>Amount</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $row['id'] . "</td>
            <td>" . $row['order_date'] . "</td>
            <td>" . $row['serial_id'] . "</td>
            <td>" . $row['order_name'] . "</td>
            <td>" . $row['quantity'] . "</td>
            <td>$" . $row['amount'] . "</td>
          </tr>";
}
echo "</table>";
?>
