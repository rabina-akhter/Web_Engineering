const products = [
    {
        name: "Red Tomato",
        image: "https://media.post.rvohealth.io/wp-content/uploads/2020/09/AN313-Tomatoes-732x549-Thumb-732x549.jpg",
        oldPrice: 24.99,
        discount: 20,
    },
    {
        name: "Sweet Potato",
        image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Ipomoea_batatas_006.JPG/1200px-Ipomoea_batatas_006.JPG",
        oldPrice: 29.99,
        discount: 25,
    },
    {
        name: "Cabbage",
        image: "https://assets.clevelandclinic.org/transform/LargeFeatureImage/871f96ae-a852-4801-8675-683191ce372d/Benefits-Of-Cabbage-589153824-770x533-1_jpg",
        oldPrice: 19.99,
        discount: 15,
    },
    {
        name: "Carrot",
        image: "https://images.contentstack.io/v3/assets/bltcedd8dbd5891265b/bltef27f8733b883dac/66707bf8010b1f3bc3826b5b/history-of-carrots-basket-of-carrots-1200x675-1.jpg?q=70&width=3840&auto=webp",
        oldPrice: 34.99,
        discount: 30,
    },
];

const container = document.querySelector(".products");

products.forEach(product => {
    const newPrice = (product.oldPrice * (1 - product.discount / 100)).toFixed(2);
    const item = document.createElement("div");
    item.className = "product";

    item.innerHTML = `
        <img src="${product.image}" alt="${product.name}" />
        <h3>${product.name}</h3>
        <p class="old-price">$${product.oldPrice}</p>
        <p class="new-price">$${newPrice}</p>
        <div class="discount-tag">${product.discount}% OFF</div>
    `;
    container.appendChild(item);
});

// Search functionality
document.getElementById("search-btn").addEventListener('click', function() {
    const searchTerm = document.querySelector('input').value.toLowerCase();
    const productItems = document.querySelectorAll('.product');

    productItems.forEach(item => {
        const productName = item.querySelector('h3').textContent.toLowerCase();
        if (!productName.includes(searchTerm)) {
            item.style.display = 'none'; // Hide items that don't match search
        } else {
            item.style.display = 'block'; // Show matching items
        }
    });
});

// Cart functionality
let cartCount = 0;

document.querySelector('.order-now-btn').addEventListener('click', function() {
    cartCount++;
    document.querySelector('.cart-number').textContent = cartCount;
});
