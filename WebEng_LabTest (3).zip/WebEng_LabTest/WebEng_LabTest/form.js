const form = document.getElementById('mealForm');
const tableBody = document.querySelector('#mealTable tbody');

form.onsubmit = function (e) {
  e.preventDefault();

  const mealName = document.getElementById('mealName').value.trim();
  const day = document.getElementById('day').value;
  const types = [...document.querySelectorAll('input[name="type"]:checked')].map(i => i.value);
  const errorBox = document.getElementById('error');
  errorBox.textContent = '';

  if (mealName.length < 3) {
    errorBox.textContent = "Meal name must be at least 3 characters.";
    return;
  }
  if (!day) {
    errorBox.textContent = "Please select a day.";
    return;
  }
  if (types.length === 0) {
    errorBox.textContent = "Select at least one meal type.";
    return;
  }

  const dayRow = [...tableBody.children].find(row => row.firstChild.textContent === day);
  if (dayRow) {
    const meals = dayRow.children[1].textContent.split(", ");
    if (meals.length >= 3) {
      errorBox.textContent = "This day already has 3 meals.";
      return;
    }
    meals.push(`${mealName} (${types.join(", ")})`);
    dayRow.children[1].textContent = meals.join(", ");
  } else {
    const row = tableBody.insertRow();
    row.insertCell().textContent = day;
    row.insertCell().textContent = `${mealName} (${types.join(", ")})`;
  }

  form.reset();
};
