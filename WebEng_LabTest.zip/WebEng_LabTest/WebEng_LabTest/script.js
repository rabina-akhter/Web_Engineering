const greeting = document.getElementById('greeting');
const date = document.getElementById('date');

const now = new Date();
const hour = now.getHours();
let greet = "Hello!";
if (hour < 12) greet = "Good Morning, Chef!";
else if (hour < 18) greet = "Good Afternoon, Chef!";
else greet = "Good Evening, Chef!";

greeting.textContent = greet;
date.textContent = now.toDateString();

// Toggle Instructions
function toggleInstructions(btn) {
  const steps = btn.nextElementSibling;
  if (steps.style.display === "none") {
    steps.style.display = "block";
    btn.textContent = "Hide Steps";
  } else {
    steps.style.display = "none";
    btn.textContent = "Show Steps";
  }
}

// Cooking Tips
const tips = [
  "Always taste your food as you cook.",
  "Let your meat rest after cooking.",
  "Use sharp knives for better control.",
  "Clean as you go to save time.",
  "Use fresh ingredients for best flavor."
];

document.getElementById('tipBtn').onclick = () => {
  const tip = tips[Math.floor(Math.random() * tips.length)];
  const box = document.getElementById('tipBox');
  box.style.backgroundColor = `hsl(${Math.random() * 360}, 70%, 90%)`;
  box.textContent = tip;
};
